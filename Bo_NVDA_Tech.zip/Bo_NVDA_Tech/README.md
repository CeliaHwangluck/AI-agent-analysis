# NVDA Technical Analyst Agent

This project implements a reproducible technical-analysis backtesting and reporting pipeline:

- Fetch 10y OHLCV for NVDA (Yahoo Finance) and compute close-to-close returns.
- Train/Val/Test split (2019-12-31 / 2022-12-31 by default).
- LIGHT engine grid-search on validation Sharpe.
- FULL engine run for the chosen parameters.
- Report outputs (MAIN and APPENDIX):
  - Main figures (`outputs/main/`): `FULL_price.png`, `FULL_equity.png`, `FULL_drawdown.png`, `FULL_annual_return.png`
  - Main tables (`outputs/main/`): `FULL_metrics.csv`, `FULL_annual_returns.csv`
  - Appendix tables (`outputs/appendix/`, if enabled): `FULL_sensitivity.csv`
  - Split tables (`outputs/main/`, diagnostic): `FULL_split_metrics.csv`

## Quickstart (macOS/Linux)

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python3 run_demo.py --ticker NVDA --years 10 --as_of latest --no_llm
```

Outputs are saved under:
- `outputs/main/` (main figures/metrics)
- `outputs/appendix/` (appendix figures/experiments)
- `outputs/<TICKER>_investment_report.md` (report source text; written only when LLM is enabled)
- `outputs/<TICKER>_investment_report.html` (final report HTML; written when `--export_html` is used)
- `outputs/report_inputs.json` (deterministic payload used by the report)

## Environment Variables (.env)

For reproducibility and ease of grading, this repo supports a local `.env` file (loaded by `run_demo.py`).

1) Copy `.env.example` to `.env`
2) Fill in your keys (do **not** commit `.env`)

Used keys:
- `ALPHA_VANTAGE_API_KEY` (required only if you run Idaliia fundamental analysis via `--run_idaliia`)
- `OPENAI_API_KEY` (required only if you generate the LLM report via OpenAI)

## Notes on data sources

- Primary: Yahoo Finance via yfinance. `auto_adjust=True` is used by default.
- Robustness (stable mode): if Yahoo/yfinance endpoints are blocked/unstable, the pipeline will try a Yahoo chart endpoint,
  then fall back to the most recent local Yahoo cache (if available), and only then fall back to Stooq.
  Stooq prices are **unadjusted**, so returns differ from adjusted-close results if the Stooq fallback is used.
## Report workflow (HTML + optional OpenAI narrative)

## Disclosure: Commercial LLM API
This project uses a **commercial/premium LLM API (OpenAI)** to draft the report narrative when enabled.
All figures and metrics in the report come from deterministic code outputs written to `outputs/report_inputs.json`.

### 1) Run technical pipeline (main + appendix outputs)
```bash
python3 run_demo.py --ticker NVDA --years 10 --train_end 2019-12-31 --val_end 2022-12-31 --no_llm
```
Notes:
- Appendix pattern experiment is **enabled by default**. Use `--no_patterns_appendix` to disable it.

### Real-time mode (latest data)
By default, `--as_of` is set to `latest` (real-time mode). To fetch the latest available data at run time:
```bash
python3 run_demo.py --ticker NVDA --as_of latest --years 10 --yes_openai --openai_model gpt-4o-mini --export_html
```
Note: results may differ over time as new market data arrives and data vendors revise historical adjustments.

### Reproducible mode (pinned as-of date)
To reproduce a specific report, run with the same pinned as-of date shown in `outputs/report_inputs.json` (`run_params.as_of`):
```bash
python3 run_demo.py --ticker NVDA --as_of 2026-01-31 --years 10 --yes_openai --openai_model gpt-4o-mini --export_html
```
If Yahoo is temporarily unavailable, the pipeline may use a local Yahoo cache and will disclose this in the report.

### 2) Generate the narrative report via OpenAI (optional)
If you want the narrative report (LLM-written Markdown), set `OPENAI_API_KEY` in `.env` or your shell and run:
```bash
python3 run_demo.py --ticker NVDA --yes_openai --openai_model gpt-4o-mini --export_html
```
To avoid any API calls, run the backtest only:
```bash
python3 run_demo.py --ticker NVDA --no_llm
```
If you want to explicitly enable the appendix pattern experiment (already ON by default), use:
```bash
python3 run_demo.py --ticker NVDA --use_patterns_appendix
```

### 3) Streamlit web app
```bash
streamlit run webapp.py
```

### PDF export (via browser print)
This packaged project does not generate PDFs in code. To create a PDF:
- Open `outputs/<TICKER>_investment_report.html` in a browser
- Print → Save as PDF (A4)

### Fundamental overlay (external)
Edit `inputs/fundamental_override.json` based on Idaliia report output.
- Fundamentals are used **only as a risk-control overlay** (position sizing cap). They do **not** change the technical entry/exit signal logic.
- BUY/HOLD: typically non-binding (no effective constraint on exposure).
- SELL: the maximum allowable exposure is reduced via `--sell_leverage_mult` (interpretable risk-off filter).
Enable in backtest with:
```bash
python3 run_demo.py --fundamental_mode filter --sell_leverage_mult 0.3
```
Default is `filter` (overlay is applied to the backtest as a sizing cap).

To disable the overlay in the backtest (report-only context), run:
```bash
python3 run_demo.py --fundamental_mode report_only
```

## Included sample HTML report (for reference)

This repo includes a **pre-generated** example report so you can view the final deliverable without
needing to run any code or call any APIs.

Where to find it:
- HTML: `sample_outputs/outputs/NVDA_investment_report.html`
- Markdown source: `sample_outputs/outputs/NVDA_investment_report.md`
- Deterministic inputs (all metrics/figures are derived from this JSON): `sample_outputs/outputs/report_inputs.json`
- Figures and tables:
  - Main: `sample_outputs/outputs/main/`
  - Appendix: `sample_outputs/outputs/appendix/`

How to view:
- Open `sample_outputs/outputs/NVDA_investment_report.html` directly in a browser.
- If you want a PDF, use browser Print → Save as PDF (A4).

What the sample demonstrates (high level):
- 10-year OHLCV pipeline for NVDA with deterministic backtest outputs (metrics + figures).
- Main strategy report narrative generated via OpenAI (already baked into the sample Markdown/HTML).
- Appendix experiments (e.g., only MA crossover, or adding patterns) and a parameter sensitivity grid.
- External fundamental overlay integrated as a **risk-control cap** (position sizing only), not as an alpha signal.

Important: whether fundamentals were actually applied in the backtest
- The sample outputs were generated with the fundamental overlay **enabled in the backtest**:
  `run_params.fundamental_mode=filter` and `run_params.overlay_used_in_backtest=true`
  (see `sample_outputs/outputs/report_inputs.json`).

Reproducing the sample vs reproducing *a run*
- The included sample is a static artifact (you can open it without running anything).
- If you re-run the pipeline with `--as_of latest`, outputs may differ because data updates over time.
- For reproducibility, use the pinned `run_params.as_of` shown in `outputs/report_inputs.json` / `sample_outputs/outputs/report_inputs.json`.
